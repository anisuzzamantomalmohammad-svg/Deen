import React, { useMemo, useState } from 'react';
import { FlatList, ScrollView, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useApp } from '../state/store';
import { useNav } from '../nav';
import { useTheme, useT, Serif, Body, Label, Card, Press, Arabic, Segmented, Chip, Input, Tick, SectionLabel, Empty } from '../ui/kit';
import { ScreenTitle, Stepper } from '../ui/parts';
import { useLayout, timeStr } from '../ui/hooks';
import { PRAYER_NAMES, addDays, addMinutes } from '../lib/prayer';
import { DUAS, DUA_CATEGORIES } from '../data/duas';
import { duaText, categoryName } from '../data/duaText';
import { KALIMAS } from '../data/kalimas';
import { kalimaText } from '../data/kalimaText';
import { infoText } from '../data/infoText';

function useNafilWindows() {
  const app = useApp();
  const { today, getDay, coords, data } = app;
  const tz = coords.timezone;
  const now = new Date();
  const d = getDay(today);
  const beforeFajr = now < d.Fajr;
  const nightStart = beforeFajr ? getDay(addDays(today, -1)).Maghrib : d.Maghrib;
  const nightEnd = beforeFajr ? d.Fajr : getDay(addDays(today, 1)).Fajr;
  const lastThird = new Date(nightEnd.getTime() - (nightEnd - nightStart) / 3);
  return { tz, tahajjud: [lastThird, addMinutes(nightEnd, -(data.safetyBuffer || 0))], duha: [addMinutes(d.Sunrise, 15), addMinutes(d.Dhuhr, -10)], d };
}

function DailyView() {
  const app = useApp();
  const nav = useNav();
  const th = useTheme();
  const t = useT();
  const { today } = app;
  const w = useNafilWindows();
  const h = app.hijri(today);
  const ramadan = h.monthIndex === 8;
  const done = app.data.completedSunnahByDay[today.toDateString()] || {};
  const fmt = (a, b) => `${timeStr(t, a, w.tz)} – ${timeStr(t, b, w.tz)}`;
  const items = [
    { key: 'tahajjud', info: 'tahajjud', icon: 'moon', win: fmt(w.tahajjud[0], w.tahajjud[1]) },
    { key: 'duha', info: 'duha', icon: 'sun', win: fmt(w.duha[0], w.duha[1]) },
    { key: 'dhikr', info: 'adhkar', icon: 'repeat', win: t('After Fajr and after Asr') },
    ...(!ramadan ? [{ key: 'roja', info: 'fast', icon: 'sunrise', win: t('Seheri to Iftar') }] : []),
  ];
  const doneCount = items.filter((i) => done[i.key]).length;
  const I = infoText(t.lang).NAWAFIL;
  const qada = app.data.qadaCounts || {};
  const setQada = (n, v) => app.update((p) => ({ qadaCounts: { ...p.qadaCounts, [n]: Math.max(0, v) } }));
  const totalQada = PRAYER_NAMES.reduce((a, n) => a + (qada[n] || 0), 0);
  const tb = app.data.tasbih || {};

  return (
    <View>
      <Card onPress={() => nav.push('tasbih')} style={{ marginTop: 14, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 }} active>
        <View style={{ width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: th.accent, alignItems: 'center', justifyContent: 'center' }}>
          <Serif bold size={15} color={th.accent}>{t.num(tb.count || 0)}</Serif>
        </View>
        <View style={{ flex: 1 }}>
          <Serif size={17}>{t('Tasbih counter')}</Serif>
          <Body size={11.5} color={th.muted}>{t('Tap anywhere to count · target {n}', { n: tb.target || 33 })}</Body>
        </View>
        <Feather name="chevron-right" size={16} color={th.faint} />
      </Card>

      <SectionLabel right={<Label>{t('{n} of {m}', { n: doneCount, m: items.length })}</Label>}>{t('Sunnah & nawafil')}</SectionLabel>
      <Card style={{ paddingVertical: 2 }}>
        {items.map((it, i) => (
          <View key={it.key}>
            {i > 0 && <View style={{ height: 1, backgroundColor: th.line, marginHorizontal: 14 }} />}
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 11, paddingLeft: 14, paddingRight: 8 }}>
              <Press onPress={() => nav.openSheet('nawafil', { k: it.info, window: it.win })} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 }} scaleTo={0.99}>
                <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: th.accentSoft, alignItems: 'center', justifyContent: 'center' }}>
                  <Feather name={it.icon} size={15} color={th.accent} />
                </View>
                <View style={{ flex: 1 }}>
                  <Body size={14} weight="med">{I[it.info].title}</Body>
                  <Body size={11.5} color={th.muted}>{it.win}</Body>
                </View>
              </Press>
              <Press onPress={() => app.toggleSunnah(today, it.key)} hitSlop={8} style={{ padding: 6 }} accessibilityLabel={I[it.info].title} accessibilityState={{ checked: !!done[it.key] }}>
                <Tick done={!!done[it.key]} />
              </Press>
            </View>
          </View>
        ))}
      </Card>

      <SectionLabel right={<Label>{totalQada ? t('{n} to make up', { n: totalQada }) : t('All caught up')}</Label>}>{t('Qada · missed prayers')}</SectionLabel>
      <Card style={{ paddingVertical: 2 }}>
        {PRAYER_NAMES.map((n, i) => (
          <View key={n}>
            {i > 0 && <View style={{ height: 1, backgroundColor: th.line, marginHorizontal: 14 }} />}
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 9, paddingHorizontal: 14 }}>
              <View style={{ flex: 1 }}>
                <Serif size={15}>{t(n)}</Serif>
                <Body size={11} color={th.muted}>{qada[n] ? t('{n} to make up', { n: qada[n] }) : t('All caught up')}</Body>
              </View>
              <Stepper value={qada[n] || 0} minusIcon="check" onMinus={() => { if (qada[n]) { setQada(n, qada[n] - 1); app.haptic('success'); } }} onPlus={() => setQada(n, (qada[n] || 0) + 1)} />
            </View>
          </View>
        ))}
      </Card>
      <Body size={11} color={th.faint} style={{ marginTop: 6 }}>{t('+ adds a missed prayer, ✓ marks one made up.')}</Body>
    </View>
  );
}

function KalimaCard({ k }) {
  const nav = useNav();
  const th = useTheme();
  const t = useT();
  const kt = kalimaText(k, t.lang);
  return (
    <Card onPress={() => nav.push('dua', { kalima: k.id })} style={{ padding: 14, marginBottom: 10 }}>
      <Label size={8.5} color={th.accent}>{kt.title}</Label>
      <Arabic size={21} style={{ textAlign: 'right', marginTop: 6 }}>{k.arabic}</Arabic>
      <Body size={12} color={th.muted} style={{ fontStyle: 'italic', marginTop: 2 }} numberOfLines={2}>{k.transliteration}</Body>
      <Body size={12.5} style={{ marginTop: 4 }} numberOfLines={3}>{kt.translation}</Body>
      {kt.untranslated ? <Body size={10.5} color={th.faint} style={{ marginTop: 3 }}>{t('English meaning · Bangla not added yet')}</Body> : null}
    </Card>
  );
}

function DuaCard({ d, fav, onFav }) {
  const nav = useNav();
  const th = useTheme();
  const t = useT();
  const dt = duaText(d, t.lang);
  return (
    <Card onPress={() => nav.push('dua', { id: d.id })} style={{ padding: 14, marginBottom: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Label size={8} color={th.accent} style={{ flex: 1 }}>{categoryName(d.category, t.lang)}</Label>
        <Press onPress={onFav} hitSlop={12} haptic accessibilityLabel={fav ? t('Remove from saved') : t('Save')}>
          <Feather name="star" size={17} color={fav ? th.accent : th.faint} style={fav ? { opacity: 1 } : null} />
        </Press>
      </View>
      <Serif size={16} style={{ marginTop: 2 }}>{dt.title}</Serif>
      <Arabic size={20} style={{ textAlign: 'right', marginTop: 4 }} numberOfLines={3}>{d.arabic}</Arabic>
      <Body size={12.5} color={th.muted} numberOfLines={2}>{dt.translation}</Body>
      {dt.untranslated ? <Body size={10.5} color={th.faint} style={{ marginTop: 3 }}>{t('English meaning · Bangla not added yet')}</Body> : null}
    </Card>
  );
}

export default function IbadahScreen() {
  const app = useApp();
  const th = useTheme();
  const t = useT();
  const L = useLayout();
  const [tab, setTab] = useState('daily');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('All');
  const favs = app.data.favoriteDuaIds || [];
  const toggleFav = (id) => app.update((p) => ({ favoriteDuaIds: (p.favoriteDuaIds || []).includes(id) ? p.favoriteDuaIds.filter((x) => x !== id) : [...(p.favoriteDuaIds || []), id] }));

  const duas = useMemo(() => {
    if (tab !== 'duas') return [];
    const term = q.trim().toLowerCase();
    return DUAS.filter((d) => {
      if (cat === 'saved' && !favs.includes(d.id)) return false;
      if (cat !== 'All' && cat !== 'saved' && d.category !== cat) return false;
      if (!term) return true;
      const dt = duaText(d, t.lang);
      return [d.title, d.translation, d.transliteration, d.category, d.note || '', d.source || '', dt.title, dt.translation].some((x) => (x || '').toLowerCase().includes(term));
    });
  }, [tab, q, cat, favs, t.lang]);

  const header = (
    <View>
      <ScreenTitle title={t('Ibadah')} arabic="عبادة" sub={t('Your daily worship')} />
      <Segmented
        style={{ marginTop: 10 }}
        value={tab}
        onChange={(v) => { app.haptic(); setTab(v); }}
        options={[{ id: 'daily', label: t('Daily') }, { id: 'duas', label: t('Duas') }, { id: 'kalimas', label: t('Kalimas') }]}
      />
      {tab === 'daily' ? <DailyView /> : null}
      {tab === 'kalimas' ? (
        <View style={{ marginTop: 14 }}>
          {KALIMAS.map((k) => <KalimaCard key={k.id} k={k} />)}
        </View>
      ) : null}
      {tab === 'duas' ? (
        <View style={{ marginTop: 14 }}>
          <Input value={q} onChangeText={setQ} placeholder={t('Search {n} duas (e.g. sleep, travel, rain)', { n: DUAS.length })} autoCorrect={false} returnKeyType="search" />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 10, marginHorizontal: -L.pad }} contentContainerStyle={{ paddingHorizontal: L.pad }}>
            <Chip label={t('All')} active={cat === 'All'} onPress={() => setCat('All')} />
            <Chip label={t('Saved')} icon="star" active={cat === 'saved'} onPress={() => setCat('saved')} />
            {DUA_CATEGORIES.map((c) => <Chip key={c} label={categoryName(c, t.lang)} active={cat === c} onPress={() => setCat(c)} />)}
          </ScrollView>
          <Body size={11} color={th.faint} style={{ marginTop: 8, marginBottom: 6 }}>{t('{n} duas', { n: duas.length })}</Body>
        </View>
      ) : null}
    </View>
  );

  return (
    <FlatList
      data={duas}
      keyExtractor={(d) => String(d.id)}
      renderItem={({ item }) => <DuaCard d={item} fav={favs.includes(item.id)} onFav={() => toggleFav(item.id)} />}
      ListHeaderComponent={header}
      ListEmptyComponent={tab === 'duas' ? <Empty icon={cat === 'saved' ? 'star' : 'search'} title={cat === 'saved' ? t('No saved duas yet') : t('No duas found')} text={cat === 'saved' ? t('Tap the star on any dua to keep it here.') : t('Try another word or a different category.')} /> : null}
      contentContainerStyle={{ paddingTop: L.insets.top + 16, paddingHorizontal: L.pad, paddingBottom: L.bottomSpace }}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      initialNumToRender={8}
      windowSize={7}
    />
  );
}
